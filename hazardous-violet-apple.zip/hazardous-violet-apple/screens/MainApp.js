import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import HomeTabs from './HomeTabs';
import RecipesScreen from './RecipesScreen';

const Drawer = createDrawerNavigator();

export const MainApp = () => (
  <Drawer.Navigator>
    <Drawer.Screen name="Home" component={HomeTabs} />
    <Drawer.Screen name="Recipes" component={RecipesScreen} />
  </Drawer.Navigator>
);
