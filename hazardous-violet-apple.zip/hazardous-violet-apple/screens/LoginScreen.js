import React, { useState } from 'react';
import { View, TextInput, Button, Text, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native'; // React Navigation hook

const LoginScreen = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigation = useNavigation(); // React Navigation hook

  const handleLogin = async () => {
    if (!username.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both username and password');
      return;
    }

    try {
      // API call
      const response = await fetch('https://dummyjson.com/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username:'emilys',
          password:'emilyspass',
          expiresInMins: 30, // optional expiration time
        }),
        credentials: 'include', // Include cookies if required
      });

      const data = await response.json();

      if (response.ok) {
        // On successful login, navigate to Home screen
        const token = data.token; // Extract token from API response
        console.log('Login successful, token:', token);
        navigation.replace('Home'); // Navigate to Home screen
      } else {
        // Show error message if login fails
        Alert.alert('Login Failed', data.message || 'Invalid credentials');
      }
    } catch (error) {
      // Handle network or server errors
      console.error('Error during login:', error);
      Alert.alert('Login Failed', 'An error occurred. Please try again later.');
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', padding: 16 }}>
      <Text style={{ fontSize: 24, textAlign: 'center', marginBottom: 20 }}>
        Login
      </Text>
      <TextInput
        placeholder="Username"
        value={username}
        onChangeText={setUsername}
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          padding: 10,
          marginBottom: 15,
          borderRadius: 5,
        }}
      />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        
        style={{
          borderWidth: 1,
          borderColor: '#ccc',
          padding: 10,
          marginBottom: 15,
          borderRadius: 5,
        }}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
};

export default LoginScreen;
