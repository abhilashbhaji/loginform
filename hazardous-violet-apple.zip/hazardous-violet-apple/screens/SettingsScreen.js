import React from 'react';
import { View, Button } from 'react-native';
import { useTheme } from '../App';  // Import from App.js

const SettingsScreen = () => {
  const { toggleTheme } = useTheme();  // Use the hook from context
  
  return (
    <View>
      <Button title="Toggle Theme" onPress={toggleTheme} />
    </View>
  );
};

export default SettingsScreen;
