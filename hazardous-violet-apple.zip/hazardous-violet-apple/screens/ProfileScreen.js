import React, { useState, useEffect, useContext } from 'react';
import { View, Text, Button } from 'react-native';
import { AuthContext } from '../contexts/AuthContext';
import axios from 'axios';

const ProfileScreen = () => {
  // const { authToken, clearAuthToken } = useContext(AuthContext);
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    const fetchUser = async () => {
        try {
          const response = await axios.get('https://dummyjson.com/auth/user', {
            headers: { Authorization: `Bearer` }
          });
          setUser(response.data);
        } catch (error) {
          clearAuthToken();
        }
    };
    fetchUser();
  });

  if (!user) return <Text>Loading...</Text>;
  
  return (
    <View>
      <Text>Welcome, {user.username}!</Text>
      <Button title="Logout" onPress={clearAuthToken} />
    </View>
  );
};

export default ProfileScreen;
