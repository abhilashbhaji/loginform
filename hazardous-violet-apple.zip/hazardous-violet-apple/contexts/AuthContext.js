import React, { createContext, useState, useEffect } from 'react';
import * as SecureStore from 'expo-secure-store';
import axios from 'axios';

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [authToken, setAuthToken] = useState(null);
  
  useEffect(() => {
    const loadToken = async () => {
      const token = await SecureStore.getItemAsync('authToken');
      if (token) {
        setAuthToken(token);
      }
    };
    loadToken();
  }, []);

  const saveAuthToken = async (token) => {
    await SecureStore.setItemAsync('authToken', token);
    setAuthToken(token);
  };

  const clearAuthToken = async () => {
    await SecureStore.deleteItemAsync('authToken');
    setAuthToken(null);
  };

  return (
    <AuthContext.Provider value={{ authToken, saveAuthToken, clearAuthToken }}>
      {children}
    </AuthContext.Provider>
  );
};
