import React, { useState, useEffect, createContext, useContext } from 'react';
import { Appearance } from 'react-native';
import { NavigationContainer, DefaultTheme, DarkTheme } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import LoginScreen from './screens/LoginScreen';
import HomeTabs from './screens/HomeTabs';
import RecipesScreen from './screens/RecipesScreen';
import SettingsScreen from './screens/SettingsScreen';

// Create the ThemeContext
const ThemeContext = createContext();
export const useTheme = () => useContext(ThemeContext);  // Ensure it's exported

const App = () => {
  const [theme, setTheme] = useState(Appearance.getColorScheme() || 'light');

  useEffect(() => {
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      setTheme(colorScheme || 'light');
    });
    return () => subscription.remove();
  }, []);
  
  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');
  
  // Create the Drawer navigator
  const Drawer = createDrawerNavigator();

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <NavigationContainer theme={theme === 'light' ? DefaultTheme : DarkTheme}>
        <Drawer.Navigator>
          <Drawer.Screen name="Login" component={LoginScreen} />
          <Drawer.Screen name="Home" component={HomeTabs} />
          <Drawer.Screen name="Recipes" component={RecipesScreen} />
        </Drawer.Navigator>
      </NavigationContainer>
    </ThemeContext.Provider>
  );
};

export default App;
